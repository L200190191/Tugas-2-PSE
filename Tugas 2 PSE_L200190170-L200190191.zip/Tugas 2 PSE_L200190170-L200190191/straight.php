<!doctype html>
<html lang="en">

<head>
	<!-- Required meta tags -->
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<!-- Bootstrap CSS -->
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
	<link rel="stylesheet" href="icofont/icofont.min.css">
	<!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css"> -->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
	<title>TUGAS 2 PSE</title>
</head>

<body>
	<nav class="navbar navbar-dark" style="background-color: #191970;">
		<div class="container-fluid">
			<button class="navbar-toggler navbar-md-2" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasNavbar" aria-controls="offcanvasNavbar">
				<span class="icofont-navigation-menu icofont-1x" style="color: white"></span>
			</button>
			<div class="offcanvas offcanvas-start mt-5 bg-dark" tabindex="-1" id="offcanvasNavbar" aria-labelledby="offcanvasNavbarLabel">
				<div class="offcanvas-header">
					<h3 class=" offcanvas-title" id="offcanvasNavbarLabel" style="color: white">
						<font color="white" face="arial">HITUNG DEPRESIASI</font>
					</h3>
					<span type="button" class="icofont-close icofont-2x" data-bs-dismiss="offcanvas" aria-label="Close" style="color: white"></span>
				</div>
				<div class=" offcanvas-body">
					<ul class="navbar-nav justify-content-end flex-grow-1 pe-1">
						<li class=" nav-item">
							<a class="nav-link" href="home.html">
								<font face="arial" size="3">Home</font>
							</a>
						</li>
						<li class=" nav-item">
							<a class="nav-link active" href="straight.php">
								<font face="arial" size="3">Stright Line</font>
							</a>
						</li>
						<li class="nav-item">
							<a class="nav-link" href="reducing.php">
								<font face="arial" size="3">Reducing Balance</font>
							</a>
						</li>
						<li class="nav-item">
							<a class="nav-link" href="sum.php">
								<font face="arial" size="3">Sum of the Year</font>
							</a>
						</li>
						<li class="nav-item">
							<a class="nav-link" href="unit.php">
								<font face="arial" size="3">Unit of Activity</font>
							</a>
						</li>
					</ul>
				</div>
			</div>
		</div>
	</nav>
	<br><br>
	<figure class="text-center">
		<div class="header">
			<h2>Kalkulator Depresiasi </h2>

			<h3>Straight Line</h3>

		</div>
		<br><br>
		<?php
		$perolehan = null;
		$residu = null;
		$umur = null;
		if (isset($_GET['perolehan'])) {
			$perolehan = $_GET['perolehan'];
			$residu = $_GET['residu'];
			$umur = $_GET['umur'];
			$hasil = 0;
			$hasil = ($perolehan - $residu) / $umur;
		}
		?>
		<form class="topBefore" action="straight.php" method="get">
			<table align="center" border="0">
				<tr>
					<td>Harga Perolehan</td>
					<td>:</td>
					<td><input type="text" name="perolehan" value="<?php echo $perolehan; ?>" required></td>
				</tr>
				<tr>
					<td>Nilai Residu</td>
					<td>:</td>
					<td><input type="text" name="residu" value="<?php echo $residu; ?>" required></td>
				</tr>
				<tr>
					<td>Umur Ekonomis (Tahun)</td>
					<td>:</td>
					<td><input type="text" name="umur" value="<?php echo $umur; ?>" required></td>
				</tr>
			</table>
			<br>
			<button class="btn btn-info" type="submit">Hitung</button>
		</form>
		<br>
		<?php
		if (isset($_GET['perolehan'])) {
			$hasil = "Hasil depresiasi pertahunnya selama " . $umur . " tahun menggunakan metode Straight Line adalah " . number_format($hasil, 0, ',', '.');
			echo "<h5>$hasil</h5>";
		}
		?>
	</figure>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>

</body>

</html>